import React from "react";
import "./FormCSS.css";
//import MapDiv from "./MapDiv";
import DataTransfer from "./DataTransfer";
import OfferLetterData from "./OfferLetterData";
import MapDiv from "./MapDiv";

function FormDiv(event) {
    const { HandleChange, CompanyName } = DataTransfer();
    return ( <
        div >
        <
        div className = "Map-Div" >
        <
        form >
        <
        label className = "form-label" > { OfferLetterData[0].label } < /label>{" "} <
        br / >
        <
        input className = "input-form "
        //className={event.className}
        name = { OfferLetterData[0].name }
        onChange = { HandleChange }
        placeholder = { OfferLetterData[0].placeholder }
        type = { OfferLetterData[0].type }
        value = { CompanyName }
        id = { event.id }
        />{" "} <
        p > { CompanyName } < /p> <
        /form>{" "} <
        /div>{" "} <
        /div>
    );
}

export default FormDiv;

{
    /* <label className="form-label"> Company Name </label> <br />
                      <input
                        className="input-form "
                        //className={event.className}
                        name="company_Name"
                        placeholder="Enter Company name"
                        type=" Text "
                        value={values}
                        onChange={HandleChange}
                        id="01 "
                      />{" "}
                      <p> {values.company_Name} </p>{" "} */
}