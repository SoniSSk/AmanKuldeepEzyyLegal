import React from "react";

function PrintDocument() {
    return ( <
        div >
        <
        button > PRINT < /button>{" "} <
        /div>
    );
}

export default PrintDocument;