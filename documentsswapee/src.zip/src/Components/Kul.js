import React from "react";
import DataTransfer from "./FormStructure/DataTransfer";

function Kul(props) {
    const { CompanyName, hR_Name } = DataTransfer();
    return ( <
        div >
        <
        p > { props.value } < /p>{" "} <
        /div>
    );
}

export default Kul;