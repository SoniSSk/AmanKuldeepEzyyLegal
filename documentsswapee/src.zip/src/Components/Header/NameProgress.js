import React from "react";
import "./NameProgress.css";

function NameProgress() {
    return ( <
        div className = "header1" >
        <
        p > OFFER LETTER < /p>{" "} <
        /div>
    );
}

export default NameProgress;