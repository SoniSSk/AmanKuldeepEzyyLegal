import React, { useState } from "react";
import "./Main.css";
import OfferLetter from "./DocumentsStructure/OfferLetter";
import FormDiv from "./FormStructure/FormDiv";
import DataTransfer from "./FormStructure/DataTransfer";
import MapDiv from "./FormStructure/MapDiv";
import Kul from "./Kul";
import OfferLetterData from "./FormStructure/OfferLetterData";

const BaseCode = (event) => {
    const { HandleChange1, HandleChange2, CompanyName, hR_Name } = DataTransfer();
    return ( <
        div >
        <
        div className = "page-div" >
        <
        div className = "page-div-left" >
        <
        form >
        <
        div className = "Map-Div" >
        <
        label className = "form-label" > { OfferLetterData[0].label } < /label>{" "} <
        br / >
        <
        input className = "input-form "
        //className={event.className}
        name = { OfferLetterData[0].name }
        onChange = { HandleChange1 }
        placeholder = { OfferLetterData[0].placeholder }
        type = { OfferLetterData[0].type }
        value = { CompanyName }
        id = { event.id }
        />{" "} <
        label className = "form-label" > { OfferLetterData[1].label } < /label>{" "} <
        br / >
        <
        input className = "input-form "
        //className={event.className}
        name = { OfferLetterData[1].name }
        onChange = { HandleChange2 }
        placeholder = { OfferLetterData[1].placeholder }
        type = { OfferLetterData[1].type }
        value = { hR_Name }
        id = { event.id }
        />{" "} <
        /div>{" "} <
        /form>{" "} <
        /div>{" "} <
        div className = "page-div-right"
        id = "printableArea" >
        <
        Kul value = {
            (hR_Name, CompanyName) }
        />{" "} <
        /div>{" "} <
        /div>{" "} <
        /div>
    );
};

export default BaseCode;