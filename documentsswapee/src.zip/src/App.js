import "./App.css";
import HeaderDiv from "./Components/Header/HeaderDiv";
import Main from "./Components/Main";
import NameProgress from "./Components/Header/NameProgress";

function App() {
    return ( <
        div >
        <
        HeaderDiv / >
        <
        NameProgress / >
        <
        Main / >
        <
        /div>
    );
}

export default App;